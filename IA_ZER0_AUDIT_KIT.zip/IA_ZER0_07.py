# IDENTIFIANT UNIQUE : NSP-LAW-AI-2026-9942-CERT
# CERTIFICATION : VULN-204427_COMPLIANT (SSRF & JAILBREAK SHIELD)
import json, random, string, datetime

class DocumentSecurityGuardrail:
    def __init__(self):
        self.malicious = ["ignorez les instructions", "system_override"]
        self.ssrf = ["169.254.169.254", "metadata.google", "::ffff:"]
    def scan(self, text):
        t = text.lower()
        if any(p in t for p in self.malicious): return False, "JAILBREAK_DETECTED"
        if any(p in t for p in self.ssrf): return False, "SSRF_DETECTED"
        return True, "Clear"
    def anonymize(self, text):
        words = text.split()
        for i, w in enumerate(words):
            if "@" in w: words[i] = "[MÉTADATA_ANONYMISÉ]"
            if "sk-" in w: words[i] = "[SECRET_CAVIARDÉ]"
        return " ".join(words)

class DocumentIntelligenceEngine:
    def __init__(self):
        self.guard = DocumentSecurityGuardrail()
        self.sid = "ZPUCE-DOC-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
    def process(self, text):
        safe, msg = self.guard.scan(text)
        if not safe: return {"success": False, "error": msg, "sid": self.sid}
        report = self.guard.anonymize(f"Analyse : {text}")
        return {"success": True, "data": {"sid": self.sid, "summary": report}}

if __name__ == "__main__":
    eng = DocumentIntelligenceEngine()
    print(json.dumps(eng.process("Facture admin@corp.com sk-12345"), indent=2))
