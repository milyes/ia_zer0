import http.server
import json
import re
import random
import string
import time

PORT = 8080

class TokenBucketRateLimiter:
    def __init__(self, capacite_max=10, taux_recharge_seconde=2.0):
        self.capacite_max = float(capacite_max)
        self.taux_recharge_seconde = float(taux_recharge_seconde)
        self.jetons_actuels = float(capacite_max)
        self.dernier_check = time.time()

    def consommer_jeton(self):
        maintenant = time.time()
        temps_ecoule = maintenant - self.dernier_check
        self.dernier_check = maintenant
        self.jetons_actuels = min(self.capacite_max, self.jetons_actuels + (temps_ecoule * self.taux_recharge_seconde))
        if self.jetons_actuels >= 1.0:
            self.jetons_actuels -= 1.0
            return True
        return False

limiteur_global = TokenBucketRateLimiter()

class NetSecureProUnifiedHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        # 1. Validation du Rate Limiter (Anti-DoS)
        if not limiteur_global.consommer_jeton():
            self.send_response(429)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps({"success": False, "error": "ALERTE TRAFIC", "message": "Débit maximal dépassé."}, ensure_ascii=False).encode('utf-8'))
            return

        if self.path == "/api/analyse" or self.path == "/":
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length).decode('utf-8')
            
            # Parsing sécurisé des données
            emac_token = ""
            url_rag = ""
            texte_analyse = ""
            try:
                payload = json.loads(post_data)
                texte_analyse = payload.get("texte", "")
                emac_token = payload.get("emac_token", "")
                url_rag = payload.get("network_url", "")
            except:
                texte_analyse = post_data

            # Base de données d'authentification matérielle locale
            emac_whitelist = ["EMAC-AUTH-SECURE-NODE-01", "EMAC-AUTH-SECURE-NODE-02"]
            patterns_evasion = [r'\[::ffff:127\.', r'\[::1\]', r'127\.0\.0\.1']
            
            # Évaluation des filtres de sécurité tri-couche V-IA22
            rejeter_emac = emac_token != "" and emac_token not in emac_whitelist
            rejeter_ipv6 = any(re.search(pat, texte_analyse + url_rag) for pat in patterns_evasion)
            rejeter_prompt = any(keyword in texte_analyse.lower() for keyword in ["override", "system prompt"])

            suffixe_aleatoire = "".join(random.choices(string.ascii_uppercase, k=4))
            session_id = f"ZPUCE-{suffixe_aleatoire}"

            # Détermination du verdict
            if rejeter_emac:
                doc_type = "Alerte Sécurité EMAC (Couche 2)"
                summary = "Rejet matériel : Jeton EMAC invalide ou usurpé."
                status = "BLOQUÉE & REJETÉE"
            elif rejeter_ipv6:
                doc_type = "Alerte Évasion Réseau RAG (Couche 3)"
                summary = f"Tentative d'exploitation SSRF IPv6 interceptée."
                status = "BLOQUÉE & SÉCURISÉE"
            elif rejeter_prompt:
                doc_type = "Alerte Injection Prompt (Couche 7)"
                summary = "Tentative d'écrasement des directives système détectée."
                status = "BLOQUÉE & ASSAINIE"
            else:
                doc_type = "Rapport Général"
                summary = "Synthèse : Données conformes. Aucun vecteur d'attaque identifié."
                status = "Verified & Compliant"

            response_dict = {
                "success": True,
                "session_id": session_id,
                "document_type": doc_type,
                "summary": summary,
                "security_status": status
            }

            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            
            self.wfile.write(json.dumps(response_dict, indent=4, ensure_ascii=False).encode('utf-8'))

def lancer_serveur():
    server = http.server.HTTPServer(('0.0.0.0', PORT), NetSecureProUnifiedHandler)
    print(f"🚀 Serveur unifié [NANS Core + EMAC Guard] opérationnel sur http://localhost:{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[-] Arrêt du serveur.")

if __name__ == "__main__":
    lancer_serveur()
